﻿'use strict';
app.controller('indexController', ['$scope', '$location', function ($scope, $location) {

   

}]);