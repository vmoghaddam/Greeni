﻿'use strict';
app.controller('homeController', ['$scope', '$rootScope', '$location', function ($scope, $rootScope, $location) {
    $scope.pageTitle = "Home";
     
    ////////////////////////////////////

}]);